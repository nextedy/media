com.nextedy.polarion.media
==============================
Detailed README: com.nextedy.polarion.media/README.txt
Installation instructions: com.nextedy.polarion.media/INSTALL.txt
Licensing information: com.nextedy.polarion.media/LICENSE.pdf

